// تهيئة Firebase
const app = firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function createAccount() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    auth.createUserWithEmailAndPassword(email, password)
        .then((userCredential) => {
            // إنشاء الحساب بنجاح
            const user = userCredential.user;
            console.log('Account created successfully:', user);
            alert('تم إنشاء الحساب بنجاح!');
        })
        .catch((error) => {
            // حدث خطأ أثناء إنشاء الحساب
            console.error('Error creating account:', error);
            alert('حدث خطأ أثناء إنشاء الحساب. حاول مرة أخرى.');
            
        });
        
}
